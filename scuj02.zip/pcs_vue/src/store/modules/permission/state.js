export default {
  whiteList: ['/', 'notFound', 'login', 'forbidden', 'badGateway','register'],
  permissionMap: {
    1: {
      main: ['*']
    },
    2: {
      main: ['*']
    },
    3: {
      main: ['*']
    },
    4: {
      main: ['*']
    }
  }
}
