export default {
  getLinksData: state => userType => state.mainTypeMap[userType].linksData
}
