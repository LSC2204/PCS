export default {
  roleTypeMap: {
    1: {
      roleName: '中心管理员'
    },
    2: {
      roleName: '普通用户'
    },
    3: {
      roleName: '咨询师'
    },
    4: {
      roleName: '初访员'
    }
  }
}
