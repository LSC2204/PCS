export default {
  getUserId: state => state.id,
  getUserName: state => state.name,
  getUserType: state => state.type
}
