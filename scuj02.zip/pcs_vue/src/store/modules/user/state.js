export default {
  id: null,
  name: '',
  type: null
}
