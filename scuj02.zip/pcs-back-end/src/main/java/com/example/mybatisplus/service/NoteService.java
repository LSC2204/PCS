package com.example.mybatisplus.service;

import com.example.mybatisplus.model.domain.Note;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author cgl
 * @since 2022-07-04
 */
public interface NoteService extends IService<Note> {

}
