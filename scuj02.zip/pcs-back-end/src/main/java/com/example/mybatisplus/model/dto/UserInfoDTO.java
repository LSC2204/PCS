package com.example.mybatisplus.model.dto;

import lombok.Data;

import java.util.List;

@Data
public class UserInfoDTO {
    private List<String> time;
    private List<String> teacher;
}

